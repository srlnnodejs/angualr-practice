export const environment = {
  production: true,
  name: 'Production',
  backendPath: 'https://stagging.streetwood.pl',
  contentHost: 'https://stagging.streetwood.pl'
};
