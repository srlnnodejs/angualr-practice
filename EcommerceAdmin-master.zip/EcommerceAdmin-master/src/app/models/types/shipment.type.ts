export enum ShipmentType {
  Courier = 'Courier',
  CashOnDelivery = 'CashOnDelivery',
  Personal = 'Personal'
}
