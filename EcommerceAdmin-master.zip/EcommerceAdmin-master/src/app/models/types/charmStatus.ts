export enum charmStatus {
  Avaible,
  Unavaible
}
