export enum ProductStatus {
  Avaible,
  Unavaible,
  Deleted
}
