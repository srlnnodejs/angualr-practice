export interface CategoryForDiscount {
  id: string;
  name: string;
  selected: boolean;
}
