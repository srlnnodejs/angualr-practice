export interface StreetwoodError {
  errorCodeName: string;
  message: string;
  status: number;
  exception: any;
}
