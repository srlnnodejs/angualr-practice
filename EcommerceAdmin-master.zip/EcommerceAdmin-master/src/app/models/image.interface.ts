export interface Image {
  imageUrl: string;
  isMain: boolean;
}
