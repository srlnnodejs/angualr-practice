export interface Charm {
  id: string;
  name: string;
  nameEng: string;
  price: number;
  imagePath: string;
}
