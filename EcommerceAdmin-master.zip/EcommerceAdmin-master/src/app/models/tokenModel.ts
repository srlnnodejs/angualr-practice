export interface TokenModel {
  token: string;
  validTo: string;
  userId: string;
  email: string;
}
