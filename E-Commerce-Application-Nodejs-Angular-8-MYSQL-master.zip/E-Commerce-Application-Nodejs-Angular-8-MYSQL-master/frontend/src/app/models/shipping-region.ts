export class ShippingRegion {
    RegionId: number;
    Region: string;
}
