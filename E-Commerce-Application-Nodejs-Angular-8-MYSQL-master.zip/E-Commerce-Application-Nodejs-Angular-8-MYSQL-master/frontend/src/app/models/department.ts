export class Department {
    DepartmentId:number;
    Name:string;
    Description:string;
}
