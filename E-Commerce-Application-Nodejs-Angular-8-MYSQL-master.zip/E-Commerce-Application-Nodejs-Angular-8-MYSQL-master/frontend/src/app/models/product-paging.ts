import { Product } from './Product';

export class ProductPaging {
    ProductList: Product[];
    ProductCount: number;
}
